#ifndef __MYMQTT_H
#define __MYMQTT_H

#include "stm32f1xx_hal.h"

void Task_MQTT(void *arg);
void Task_ButtonPublish(void *arg);


#endif