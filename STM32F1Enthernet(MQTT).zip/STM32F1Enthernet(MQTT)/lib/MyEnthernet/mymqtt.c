#include "var.h"
#include "mypro.h"
#include "mymqtt.h"
#include "config.h"
#include "defines.h"

#include "FreeRTOS.h"
#include "task.h"

#include "socket.h"
#include "wizchip_conf.h"

#include <stdio.h>
#include <string.h>


/* ======================== TCP CONNECT ======================== */
static int tcp_connect(uint8_t sock, const uint8_t ip[4], uint16_t port){
    setRTR(2000);   // 2000 ms retry
    setRCR(3);      // retry 3 lần

    if (socket(sock, Sn_MR_TCP, 0, 0) != sock)
        return -1;

    (void)connect(sock, (uint8_t*)ip, port);

    uint32_t t0 = HAL_GetTick();
    for (;;) {
        uint8_t sr = getSn_SR(sock);
        if (sr == SOCK_ESTABLISHED) return 0;
        if (sr == SOCK_CLOSED)       return -4;
        if (sr == SOCK_FIN_WAIT || sr == SOCK_CLOSE_WAIT) return -5;
        if (HAL_GetTick() - t0 > 8000) {
            disconnect(sock);
            close_wiz(sock);
            return -3;
        }
        HAL_Delay(20);
    }
}

/* ======================== MQTT HELPERS ======================== */
static inline int mqtt_rl_encode(uint8_t *out, int len) {
    if (len >= 128) return -1;
    out[0] = (uint8_t)len;
    return 1;
}

static int mqtt_send_connect(uint8_t sock, const char *clientId, uint16_t keepalive) {
    uint8_t buf[128]; int p = 0;
    buf[p++] = 0x10;   // CONNECT
    int rl_pos = p++;

    // Variable header
    buf[p++] = 0x00; buf[p++] = 0x04;
    buf[p++] = 'M'; buf[p++] = 'Q'; buf[p++] = 'T'; buf[p++] = 'T';
    buf[p++] = 0x04;   // Protocol Level 4
    buf[p++] = 0x02;   // Clean session
    buf[p++] = (keepalive >> 8) & 0xFF;
    buf[p++] = (keepalive) & 0xFF;

    // Payload
    uint16_t idlen = strlen(clientId);
    buf[p++] = (idlen >> 8) & 0xFF;
    buf[p++] = idlen & 0xFF;
    memcpy(&buf[p], clientId, idlen); p += idlen;

    buf[rl_pos] = p - (rl_pos + 1);
    if (send(sock, buf, p) != p) return -11;

    // Đợi CONNACK
    uint8_t ack[4]; int n = 0; TickType_t t0 = xTaskGetTickCount();
    while (n < 4 && (xTaskGetTickCount() - t0) < pdMS_TO_TICKS(3000)) {
        int r = recv(sock, ack + n, 4 - n);
        if (r > 0) n += r; else vTaskDelay(pdMS_TO_TICKS(20));
    }
    if (n >= 4 && ack[0] == 0x20 && ack[1] == 0x02 && ack[3] == 0x00) return 0;
    return -12;
}

/* ======================== MQTT SUBSCRIBE ======================== */
static int mqtt_subscribe(uint8_t sock, const char *topic, uint16_t packetId) {
    uint8_t buf[128]; 
    int p = 0;

    buf[p++] = 0x82;   // SUBSCRIBE packet type (QoS 1)
    int rl_pos = p++;  // Reserve Remaining Length (tạm để trống)

    // Packet Identifier
    buf[p++] = (packetId >> 8) & 0xFF;
    buf[p++] = packetId & 0xFF;

    // Topic Filter
    uint16_t tlen = strlen(topic);
    buf[p++] = (tlen >> 8) & 0xFF;
    buf[p++] = tlen & 0xFF;
    memcpy(&buf[p], topic, tlen); p += tlen;

    // QoS level (0)
    buf[p++] = 0x00;

    // Remaining Length
    buf[rl_pos] = p - (rl_pos + 1);

    if (send(sock, buf, p) != p) return -1;

    // Đợi SUBACK
    uint8_t ack[5]; int n = 0; TickType_t t0 = xTaskGetTickCount();
    while (n < 5 && (xTaskGetTickCount() - t0) < pdMS_TO_TICKS(3000)) {
        int r = recv(sock, ack + n, 5 - n);
        if (r > 0) n += r; else vTaskDelay(pdMS_TO_TICKS(10));
    }

    if (n >= 5 && ack[0] == 0x90 && ack[1] == 0x03 && ack[4] == 0x00)
        return 0;

    return -2;
}

/* ======================== MQTT PING ======================== */
static inline void mqtt_ping(uint8_t sock) {
    static const uint8_t pkt[2] = {0xC0, 0x00};
    send(sock, (uint8_t*)pkt, 2);
}

static int mqtt_publish_qos0(uint8_t sock, const char *topic, const char *payload){
    uint8_t pkt[256];
    int p = 0;

    // Fixed header: PUBLISH QoS0 (0x30)
    pkt[p++] = 0x30;

    // Variable header: Topic
    uint16_t tlen = (uint16_t)strlen(topic);
    // Remaining Length = 2 + tlen + payload_len (dưới 127 cho đơn giản)
    uint16_t plen = (uint16_t)strlen(payload);
    int rem = 2 + tlen + plen;
    if (rem >= 128) return -1;                 // giản lược
    pkt[p++] = (uint8_t)rem;

    // Topic
    pkt[p++] = (tlen >> 8) & 0xFF;
    pkt[p++] = (tlen) & 0xFF;
    memcpy(&pkt[p], topic, tlen); p += tlen;

    // Payload
    memcpy(&pkt[p], payload, plen); p += plen;

    int s = send(sock, pkt, p);
    return (s == p) ? 0 : -2;
}

/* ======================== TASK MQTT ======================== */
void Task_MQTT(void *arg) {
    (void)arg;
    const uint8_t broker_ip[4] = MQTT_BROKER_IP;

    for (;;) {
        int r = tcp_connect(MQTT_SOCK, broker_ip, MQTT_BROKER_PORT);
        if (r == 0) {
            printf("TCP connected to %d.%d.%d.%d:%d\r\n",
                   broker_ip[0], broker_ip[1], broker_ip[2], broker_ip[3], MQTT_BROKER_PORT);

            r = mqtt_send_connect(MQTT_SOCK, MQTT_CLIENT_ID, MQTT_KEEPALIVE);
            if (r == 0) {
                printf("MQTT CONNACK: success\r\n");

                mqtt_subscribe(MQTT_SOCK, ROOM, 1);

                printf("Subscribed to topics: %s\r\n", ROOM);

                TickType_t lastPing = xTaskGetTickCount();
                while (getSn_SR(MQTT_SOCK) == SOCK_ESTABLISHED) {
                    if (xTaskGetTickCount() - lastPing > pdMS_TO_TICKS(30000)) {
                        mqtt_ping(MQTT_SOCK);
                        lastPing = xTaskGetTickCount();
                        printf("PINGREQ sent\r\n");
                    }

                    uint16_t rsr = getSn_RX_RSR(MQTT_SOCK);
                    if (rsr >= 2) {
                        uint8_t buf[256];
                        int len = recv(MQTT_SOCK, buf, sizeof(buf));
                        if (len > 0 && (buf[0] & 0xF0) == 0x30) {  // PUBLISH
                            uint16_t tlen = (buf[2] << 8) | buf[3];
                            char topic[64] = {0};
                            memcpy(topic, &buf[4], tlen);

                            int msg_start = 4 + tlen;
                            int msg_len = len - msg_start;
                            char payload[128] = {0};
                            memcpy(payload, &buf[msg_start], msg_len);
                            handle_json_room_status(payload, topic);
                            
                        }
                    }
                    vTaskDelay(pdMS_TO_TICKS(20));
                }
                printf("MQTT disconnected (socket closed)\r\n");
            } else {
                printf("MQTT CONNECT fail %d\r\n", r);
            }
        } else {
            printf("TCP connect fail %d\r\n", r);
        }

        close_wiz(MQTT_SOCK);
        vTaskDelay(pdMS_TO_TICKS(2000));
    }
}


void Task_ButtonPublish(void *arg){
    (void)arg;
    const char *topic = ROOM;
    char payload[64];
    int btn_prev = 1;

    for(;;){
        int level = HAL_GPIO_ReadPin(BTN_GPIO_Port, BTN_Pin);
        if(btn_prev == 1 && level == 0){
            snprintf(payload, sizeof(payload), "{ \"id\": \"%s\", \"status\": \"waiting\" }", ROOM);

            if(getSn_SR(MQTT_SOCK) == SOCK_ESTABLISHED){
                if(mqtt_publish_qos0(MQTT_SOCK, topic, payload) == 0)
                    log_i("MQTT sent: %s", payload);
                else
                    log_i("MQTT publish fail");
            }
        }
        btn_prev = level;
        vTaskDelay(pdMS_TO_TICKS(30));
    }
}