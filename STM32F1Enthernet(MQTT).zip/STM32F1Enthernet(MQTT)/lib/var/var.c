#include "var.h"

uint8_t bien_dem = 0;
