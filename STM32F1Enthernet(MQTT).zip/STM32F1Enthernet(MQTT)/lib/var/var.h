#ifndef __VAR_H
#define __VAR_H

#include "stm32f1xx_it.h"

#include "defines.h"

extern uint8_t bien_dem;

#endif