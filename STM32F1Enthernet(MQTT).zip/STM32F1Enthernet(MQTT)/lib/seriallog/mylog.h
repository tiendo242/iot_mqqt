#ifndef __MYLOG_H
#define __MYLOG_H
#include "stm32f1xx_it.h"

void LOG_Config(void);

#endif