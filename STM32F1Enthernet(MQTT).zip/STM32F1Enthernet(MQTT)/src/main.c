#include "main.h"


int main(void){
  HAL_Init();
  SystemClock_Config(); //Thach anh (Xung nhip chip) (72MHz)
  GPIO_Output_Config(); //Setup Output
  GPIO_Input_Config();  //Setup Input
  LOG_Config();
  HAL_Delay(3000);

  USART2_Config(9600);
  int err = w5500_init_spi_and_chip();

  if(err != 0){
    log_i("Enthenet fail: %d", err);
    while(1){;}
  }
  w5500_set_static_ip();
  
  /* DF_Config();
  dfp_set_volume(30);
  dfp_set_expect_ms(5000);
  dfp_play_folder_file(1, 1); */


  if(xTaskCreate(Task_MQTT, "Task_MQTT", 512, NULL, 2, NULL) != pdPASS){
    Error_Handler();
  }

  if(xTaskCreate(Task_ButtonPublish, "BTN_PUB", 256, NULL, 2, NULL) != pdPASS){
    Error_Handler();
  }

  vTaskStartScheduler();
  Error_Handler();
}
